package com.cognizant.service;

import org.springframework.stereotype.Service;
import com.cognizant.entity.Company;
import com.cognizant.entity.StockExchange;
import com.cognizant.entity.User;

@Service
public interface AdminService 
{

 Company save(Company company);

 void deleteBycompanyId(long companyId);

 StockExchange save(StockExchange stockexchange);

 Company findByCompanyId(long companyId);
 User findById(long id);
}

