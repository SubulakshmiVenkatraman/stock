package com.cognizant.entity;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="stockexchange")
public class StockExchange implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -9216174165199065590L;
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int Id;
	private String StockExchange;
	private String Brief;
	private String ContactAddress;
	private String Remarks;
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public String getStockExchange() {
		return StockExchange;
	}
	public void setStockExchange(String stockExchange) {
		StockExchange = stockExchange;
	}
	public String getBrief() {
		return Brief;
	}
	public void setBrief(String brief) {
		Brief = brief;
	}
	public String getContactAddress() {
		return ContactAddress;
	}
	public void setContactAddress(String contactAddress) {
		ContactAddress = contactAddress;
	}
	public String getRemarks() {
		return Remarks;
	}
	public void setRemarks(String remarks) {
		Remarks = remarks;
	}
	@Override
	public String toString() {
		return "StockExchange [Id=" + Id + ", StockExchange=" + StockExchange + ", Brief=" + Brief + ", ContactAddress="
				+ ContactAddress + ", Remarks=" + Remarks + "]";
	}

}
